# Serai — roadmap (complete)

_Reflects patches v1–v18. Security, features, optional polish, the org model, and its management UI are all shipped._

## Shipped

- **Guest data isolation (HIGH)** — anonymous identity + owner-scoped RLS. ✅ (v1)
- **Tenant isolation (HIGH)** — no self-reassignment of property_id. ✅ (v1)
- **Concierge endpoint (MED-HIGH)** — auth'd, ownership-checked. ✅ (v1)
- **Room/stay context in the inbox** — check-in ↔ conversation link. ✅ (v2)
- **Durable rate limiting** — Postgres-backed + DB-trigger throttles. ✅ (v3)
- **Cloudflare Turnstile** — opt-in human check. ✅ (v3)
- **ID-document retention** — auto-purge + guest notice. ✅ (v4)
- **Per-topic AI trust ladder** — suggest/approve/auto. ✅ (v4)
- **Multichannel (Twilio SMS + WhatsApp)** — inbound + outbound + numbers. ✅ (v5)
- **Test suite + CI** — unit tests + gated RLS integration + GH Actions. ✅ (v6)
- **Analytics** — containment by topic, channel mix, trust config. ✅ (v7)
- **Delivery status + retry** — sent/delivered/failed + retry. ✅ (v8)
- **Containment-over-time chart** — daily AI-containment trend. ✅ (v9)
- **Expanded integration coverage + CI job** — RLS/DB integration tests. ✅ (v10)
- **Delivery alerting** — dashboard banner for outbound failures. ✅ (v11)
- **Autonomy config-change audit** — dated change log + "→auto" markers. ✅ (v12)
- **Property onboarding checklist** — self-hiding guided setup. ✅ (v13)
- **Guest CSAT** — one-tap rating + satisfaction analytics. ✅ (v14)
- **Weekly report exports** — emailed analytics digest. ✅ (v15)
- **Multi-property rollup + SMS CSAT + summary CSV export**. ✅ (v16)
- **Organisation / group model** — org-admin cross-property READ (additive RLS). ✅ (v17)
- **Organisation management UI** — self-service rename / properties / admins, via a guarded route. ✅ (v18)

Test suite: 75 unit tests + 10 gated RLS/DB integration tests.

## Optional follow-ups (nice-to-have, not blocking)

1. **Scope the analytics property dropdown** to the org admin's org (cosmetic).
2. `properties` SELECT open to `anon` incl. `wifi_password` — move secret-ish
   fields behind the guest session.
3. Clear a stale `serai-conv-*` id the current session no longer owns.
4. Schedule pruning of `rate_limits` and old `ai_decisions` (pg_cron).
5. Paginate the add-admin user lookup if a property ever has >200 staff.
